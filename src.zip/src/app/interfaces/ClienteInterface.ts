
export interface ClienteInterface {

    cedula: string;
    nombres: string;
    apellidos: string;
    direccion: string;
    edad: number;
}